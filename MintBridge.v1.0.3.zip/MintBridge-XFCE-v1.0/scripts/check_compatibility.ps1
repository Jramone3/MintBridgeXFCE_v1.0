C:\Proyecto Jramone\MintBridge-XFCE-v1.0\scripts\
