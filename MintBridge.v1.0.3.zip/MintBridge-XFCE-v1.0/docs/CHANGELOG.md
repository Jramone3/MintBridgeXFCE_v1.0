# CHANGELOG — MintBridge XFCE v1.0

## [v1.0] — 2025-08-28
- Validación real en equipos legacy
- Presentación visual oficial generada y cifrada
- Scripts funcionales: `check_compatibility.ps1`, `mintbridge-init.ps1`, `legacy-check.ps1`, `xfce-config.sh`
- Documentación técnica reproducible
- Firma digital con Kleopatra
- Preparación para publicación en GitHub
